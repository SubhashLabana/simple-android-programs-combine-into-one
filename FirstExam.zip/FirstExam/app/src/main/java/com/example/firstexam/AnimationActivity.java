package com.example.firstexam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class AnimationActivity extends AppCompatActivity {
    ImageView image;
    Button anticlock, clock;
    int duration = 1000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_animation);
        getSupportActionBar().hide();
        image = (ImageView) findViewById(R.id.image);
        anticlock = (Button) findViewById(R.id.anticlock);
        clock = (Button) findViewById(R.id.clock);
        TextView back=(TextView)findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AnimationActivity.this,MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
        clock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.rotate_clockwise);
                image.setVisibility(View.VISIBLE);
                animation.setDuration(duration);
                animation.setRepeatCount(10);
                animation.setRepeatMode(100);
                image.startAnimation(animation);
            }
        });
        anticlock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.anticlockwise);
                image.setVisibility(View.VISIBLE);
                animation.setRepeatCount(10);
                animation.setRepeatMode(100);
                animation.setDuration(duration);
                image.startAnimation(animation);
            }
        });

    }
}
