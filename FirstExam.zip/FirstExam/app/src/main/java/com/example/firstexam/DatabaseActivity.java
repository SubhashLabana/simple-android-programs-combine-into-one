package com.example.firstexam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class DatabaseActivity extends AppCompatActivity {
    Button add, read, delete, update;
    TextView back;
    ListView listView;
    EditText fname, lname;
    //DataBaseHelpher db;
    DataBaseHelpher db = new DataBaseHelpher(DatabaseActivity.this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);
        add = (Button) findViewById(R.id.add);
        read = (Button) findViewById(R.id.read);
        update = (Button) findViewById(R.id.update);
        delete = (Button) findViewById(R.id.delete);
        back = (TextView) findViewById(R.id.back);
        //watch = (TextView) findViewById(R.id.watch);
        listView = (ListView) findViewById(R.id.listView);
        fname = (EditText) findViewById(R.id.fname);
        lname = (EditText) findViewById(R.id.lname);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AddMe();
            }
        });
        read.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ReadMe();
            }
        });
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (DatabaseActivity.this,UpdateActivity.class);
                startActivity(intent);

            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DatabaseActivity.this,DeleteActivity.class);
                startActivity(intent);
            }
        });


    }

    private void AddMe() {
        String user = fname.getText().toString();
        String pass = lname.getText().toString();
        Boolean result = db.insertData(user, pass);
        if (result == true) {
            Toast.makeText(this, "Data inserted Succcessfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Data inserted Unsucccessfully", Toast.LENGTH_SHORT).show();
        }
    }

    private void ReadMe() {
        Cursor res = db.getALLData();
        int mx = 0;
        String[] lvData = new String[res.getCount() - 0];

        while (res.moveToNext()) {
            lvData[mx] = res.getString(0) + ":" + res.getString(1) + " " + res.getString(2);
            mx++;
        }
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, lvData);
        listView.setAdapter(arrayAdapter);

    }







}
