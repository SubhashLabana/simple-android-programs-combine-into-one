package com.example.firstexam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class DeleteActivity extends AppCompatActivity {
    DataBaseHelpher db = new DataBaseHelpher(DeleteActivity.this);
    EditText deleteid;
    TextView back;
    Button delete1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);
        delete1=(Button)findViewById(R.id.delete1);
        deleteid=(EditText)findViewById(R.id.deleteid);
        back=(TextView)findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(DeleteActivity.this,DatabaseActivity.class);
                startActivity(intent);

            }
        });
        delete1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DeleteMe();
            }
        });

    }

    private void DeleteMe() {
        String id=deleteid.getText().toString();
        int result = db.deleteData(id);
        Toast.makeText(this, "Rows Affected"+id, Toast.LENGTH_SHORT).show();
    }
}
