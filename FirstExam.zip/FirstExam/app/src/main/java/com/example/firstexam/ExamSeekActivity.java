package com.example.firstexam;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class ExamSeekActivity extends AppCompatActivity implements SeekBar.OnSeekBarChangeListener {
    SeekBar seekred, seekgreen, seekblue;
    Button prev, next, prev1, next1, prev2, next2, reset, code;
    TextView back;
    ImageView imageView;
    int pro = 0;
    int red, green, blue;
    private SharedPreferences preferences;
    private static final String PROGRESS = "SEEKBAR";
    private int save;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_exam_seek);

        seekred = (SeekBar) findViewById(R.id.seekred);
        seekgreen = (SeekBar) findViewById(R.id.seekgreen);
        seekblue = (SeekBar) findViewById(R.id.seekblue);
        prev = (Button) findViewById(R.id.prev);
        next = (Button) findViewById(R.id.next);
        prev1 = (Button) findViewById(R.id.prev1);
        next1 = (Button) findViewById(R.id.next1);
        prev2 = (Button) findViewById(R.id.prev2);
        next2 = (Button) findViewById(R.id.next2);
        reset = (Button) findViewById(R.id.reset);
        code = (Button) findViewById(R.id.code);

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                seekred.setProgress(0);
                seekgreen.setProgress(0);
                seekblue.setProgress(0);
            }
        });
        code.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(ExamSeekActivity.this);
                builder.setTitle("Color Code");
                builder.setMessage("To Show Color Code");
                builder.setPositiveButton("Get", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(ExamSeekActivity.this, "Code :" + red + ":" + green + ":" + blue, Toast.LENGTH_SHORT).show();
                    }
                }).show();
            }
        });
        imageView = (ImageView) findViewById(R.id.imageView);
        back = (TextView) findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ExamSeekActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });


        seekred.setOnSeekBarChangeListener(this);
        seekgreen.setOnSeekBarChangeListener(this);
        seekblue.setOnSeekBarChangeListener(this);
        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pro--;
                //imageView.setBackgroundColor(Color.rgb(red, green, blue));
                //updateImageResources(progress);
                seekred.setProgress(pro);

            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pro++;
                //imageView.setBackgroundColor(Color.rgb(red, green, blue));
                //updateImageResources(progress);
                seekred.setProgress(pro);


            }
        });
        prev1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pro--;
                //imageView.setBackgroundColor(Color.rgb(red, green, blue));
                //updateImageResources(progress);
                seekgreen.setProgress(pro);

            }
        });
        next1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pro++;
                //imageView.setBackgroundColor(Color.rgb(red, green, blue));
                //updateImageResources(progress);
                seekgreen.setProgress(pro);

            }
        });
        prev2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pro--;
                // imageView.setBackgroundColor(Color.rgb(red, green, blue));
                //updateImageResources(progress);
                seekblue.setProgress(pro);
            }
        });
        next2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pro++;
                // imageView.setBackgroundColor(Color.rgb(red, green, blue));
                //updateImageResources(progress);
                seekblue.setProgress(pro);
            }
        });
    }

    private void updateImageResources(int progress) {
        if (pro == 2) {
            Toast.makeText(this, "progrees 2", Toast.LENGTH_SHORT).show();
            //imageView.setBackgroundColor(Color.rgb(red, green, blue));

        } else if (pro == 3) {
            Toast.makeText(this, "progrees 3", Toast.LENGTH_SHORT).show();
            //imageView.setBackgroundColor(Color.rgb(red, green, blue));

        } else if (pro == 4) {
            Toast.makeText(this, "progrees 4", Toast.LENGTH_SHORT).show();
            //imageView.setBackgroundColor(Color.rgb(red, green, blue));

        } else if (pro == 5) {
            Toast.makeText(this, "progrees 5", Toast.LENGTH_SHORT).show();
            //imageView.setBackgroundColor(Color.rgb(red, green, blue));

        } else if (pro == 6) {
            Toast.makeText(this, "progrees 6", Toast.LENGTH_SHORT).show();
            //imageView.setBackgroundColor(Color.rgb(red, green, blue));

        } else if (pro == 7) {
            Toast.makeText(this, "progrees 7", Toast.LENGTH_SHORT).show();
            //imageView.setBackgroundColor(Color.rgb(red, green, blue));

        } else if (pro == 8) {
            Toast.makeText(this, "progrees 8", Toast.LENGTH_SHORT).show();
            //imageView.setBackgroundColor(Color.rgb(red, green, blue));

        } else if (pro == 9) {
            Toast.makeText(this, "progrees 9", Toast.LENGTH_SHORT).show();
            //imageView.setBackgroundColor(Color.rgb(red, green, blue));

        } else if (pro == 10) {
            Toast.makeText(this, "progrees 10", Toast.LENGTH_SHORT).show();
            //imageView.setBackgroundColor(Color.rgb(red, green, blue));

        }

    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.item:
                preferences = getSharedPreferences(" ", MODE_PRIVATE);
                final SharedPreferences.Editor editor = preferences.edit();
                seekred.setProgress(preferences.getInt(PROGRESS, 0));
                seekgreen.setProgress(preferences.getInt(PROGRESS, 0));
                seekblue.setProgress(preferences.getInt(PROGRESS, 0));
                editor.putInt(PROGRESS,seekred.getProgress());
                editor.putInt(PROGRESS,seekgreen.getProgress());
                editor.putInt(PROGRESS,seekblue.getProgress());
                editor.commit();

                Toast.makeText(this, "You are Favourite", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.cancel:
                Toast.makeText(this, "Sorry", Toast.LENGTH_SHORT).show();
            default:
                return super.onOptionsItemSelected(item);

        }


    }
    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        switch (seekBar.getId()) {
            case R.id.seekred:
                red = progress;
                //updateImageResources(progress);
                break;
            case R.id.seekgreen:
                green = progress;
                // updateImageResources(progress);
                break;
            case R.id.seekblue:
                blue = progress;
                // updateImageResources(progress);
                break;
        }
        imageView.setBackgroundColor(Color.rgb(red, green, blue));
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {


    }

}
