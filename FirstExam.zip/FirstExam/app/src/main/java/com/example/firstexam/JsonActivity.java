package com.example.firstexam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class JsonActivity extends AppCompatActivity {
    Button dawnload;
    TextView back;
    public static  TextView privatedata;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_json);
        back=(TextView)findViewById(R.id.back);
        dawnload=(Button)findViewById(R.id.dawnload);
        privatedata=(TextView)findViewById(R.id.privatedata);
        dawnload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fetchData process = new fetchData();
                process.execute();
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(JsonActivity.this,MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }
}
