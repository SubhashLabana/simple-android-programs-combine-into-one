package com.example.firstexam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    TextView back;
    Button login;
    EditText username , password;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_login);
        getSupportActionBar().hide();
        back=(TextView)findViewById(R.id.back);
        username=(EditText)findViewById(R.id.username);
        password=(EditText)findViewById(R.id.password);
        login=(Button)findViewById(R.id.login);
        sharedPreferences = getSharedPreferences("UserInfo",0);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this,MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usernameValue = username.getText().toString();
                String passwordValue = password.getText().toString();
                String uname = sharedPreferences.getString("Username","");
                String pass = sharedPreferences.getString("Password","");
                if (uname.equals(usernameValue) && pass.equals(passwordValue))
                {
                    Toast.makeText(LoginActivity.this, "SuccessFull Login", Toast.LENGTH_SHORT).show();
                    //Intent intent = new Intent(LoginActivity.this,HomeActivity.class);
                    //startActivity(intent);
                    //finish();
                }
                else
                {
                    Toast.makeText(LoginActivity.this, "Invalid Input!", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }

}
