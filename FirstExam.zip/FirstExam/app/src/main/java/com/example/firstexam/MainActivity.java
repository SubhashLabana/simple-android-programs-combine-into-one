package com.example.firstexam;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity  {

    Button login,register,rating,list,google,call,internet,seekbar,camera,contact,examseek,anim,json,database,shareList,sqLite;
    EditText username, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        username=(EditText)findViewById(R.id.username);
        password=(EditText)findViewById(R.id.password);
        login=(Button)findViewById(R.id.login);
        register=(Button)findViewById(R.id.register);
        rating =(Button)findViewById(R.id.rating);
        list=(Button)findViewById(R.id.list);
        google =(Button)findViewById(R.id.google);
        call =(Button)findViewById(R.id.call);
        internet =(Button)findViewById(R.id.internet);
        seekbar =(Button)findViewById(R.id.seekbar);
        contact=(Button)findViewById(R.id.contact);
        camera=(Button)findViewById(R.id.camera);
        examseek=(Button)findViewById(R.id.examseek);
        anim=(Button)findViewById(R.id.anim);
        json=(Button)findViewById(R.id.json);
        database=(Button)findViewById(R.id.database);
        shareList=findViewById(R.id.shareList);
        sqLite=findViewById(R.id.sqLite);
        sqLite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (MainActivity.this,SQLDatabase.class);
                startActivity(intent);
            }
        });
        shareList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (MainActivity.this,SharedList.class);
                startActivity(intent);

            }
        });
        json.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent  intent = new Intent(MainActivity.this, JsonActivity.class);
                startActivity(intent);

            }
        });
        database.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent  intent = new Intent(MainActivity.this, DatabaseActivity.class);
                startActivity(intent);

            }
        });
        anim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent  intent = new Intent(MainActivity.this, AnimationActivity.class);
                startActivity(intent);

            }
        });
        examseek.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent  intent = new Intent(MainActivity.this, ExamSeekActivity.class);
                startActivity(intent);

            }
        });
        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent  intent = new Intent(MainActivity.this, ContactActivity.class);
                startActivity(intent);

            }
        });
        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent  intent = new Intent(MainActivity.this, CameraActivity.class);
                startActivity(intent);

            }
        });
        internet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent  intent = new Intent(MainActivity.this, InternetActivity.class);
                startActivity(intent);

            }
        });
        seekbar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent  intent = new Intent(MainActivity.this, SeekBarActivity.class);
                startActivity(intent);

            }
        });
        google.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent  intent = new Intent(MainActivity.this, WebViewActivity.class);
                startActivity(intent);

            }
        });
        list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent  intent = new Intent(MainActivity.this, ListViewActivity.class);
                startActivity(intent);

            }
        });
        rating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent  intent = new Intent(MainActivity.this,RatingActivity.class);
                startActivity(intent);

            }
        });
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent  intent = new Intent(MainActivity.this,RegisterActivity.class);
                startActivity(intent);

            }
        });
        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent  intent = new Intent(MainActivity.this,CallActivity.class);
                startActivity(intent);

            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usernameValue=username.getText().toString();
                String passwordValue=password.getText().toString();
                if (usernameValue.equals("Subhash") && passwordValue.equals("Labana"))
                {
                    Intent intent = new Intent(MainActivity.this,HomeActivity.class);
                    intent.putExtra("UserName",usernameValue);
                    startActivity(intent);

                    Toast.makeText(MainActivity.this, "Login Successfull", Toast.LENGTH_SHORT).show();

                }
                else
                {

                    Toast.makeText(MainActivity.this, "Login Unsuccessfull", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }

}
