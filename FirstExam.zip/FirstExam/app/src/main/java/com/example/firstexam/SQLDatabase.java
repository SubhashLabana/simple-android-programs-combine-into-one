package com.example.firstexam;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SQLDatabase extends AppCompatActivity {
    Button login, back;
    TextView registerPage;
    EditText username, password;
    DataBaseHelpher db = new DataBaseHelpher(SQLDatabase.this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_s_q_l_database);

        login = findViewById(R.id.login);
        back = findViewById(R.id.back);
        registerPage = findViewById(R.id.registerPage);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString();
                String pass = password.getText().toString();
                Boolean CheckuserPass=db.userPass(user,pass);
                if (CheckuserPass==true){
                    Toast.makeText(getApplicationContext(),"Successfully Login", Toast.LENGTH_SHORT).show();

                }
                else
                {
                    Toast.makeText(getApplicationContext(), "Sorry!!!!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        registerPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SQLDatabase.this, registerSQL.class);
                startActivity(intent);
            }

        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SQLDatabase.this, MainActivity.class);
                startActivity(intent);

            }
        });


    }
}
