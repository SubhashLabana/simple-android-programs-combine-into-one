package com.example.firstexam;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class SeekBarActivity extends AppCompatActivity implements SeekBar.OnSeekBarChangeListener, View.OnClickListener {
    SeekBar seekred, seekgreen, seekblue;
    Button toast, alert;
    TextView back;
    ImageView imageview;
    private int red, green, blue;
    ////
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_seek_bar);
        getSupportActionBar().hide();

        seekred = (SeekBar) findViewById(R.id.seekred);
        seekgreen = (SeekBar) findViewById(R.id.seekgreen);
        seekblue = (SeekBar) findViewById(R.id.seekblue);
        toast = (Button) findViewById(R.id.toast);
        alert = (Button) findViewById(R.id.alert);
        back = (TextView) findViewById(R.id.back);
        imageview = (ImageView) findViewById(R.id.imageview);
        seekred.setOnSeekBarChangeListener(this);
        seekgreen.setOnSeekBarChangeListener(this);
        seekblue.setOnSeekBarChangeListener(this);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SeekBarActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
        alert.setOnClickListener(this);
        toast.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        if (v == toast) {
            showcustomtoast("");
        } else if (v == alert) {
            showalertdialog("");
        }
    }

    private void showalertdialog(String s) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setTitle("Alert Dialog");
        builder.setMessage("To use of custom toast");
        builder.setPositiveButton("Show Code", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
              showcustomtoast("ok Clicked");

            }
        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                showcustomtoast("No Clicked");
            }
        }).setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                showcustomtoast("Cancelled");
            }
        }).show();
    }

    private void showcustomtoast(String s) {
        Toast toast = new Toast(this);
        View view = getLayoutInflater().inflate(R.layout.layout_toast, null);

        TextView textView = view.findViewById(R.id.textView);
       if (s.equals("")) {
            textView.setText("Custom Toast");
        } else {
            textView.setText(s);
            toast.setView(view);
            toast.show();
        }
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        switch (seekBar.getId()) {
            case R.id.seekred:
                red = progress;
                break;
            case R.id.seekgreen:
                green = progress;
                break;
            case R.id.seekblue:
                blue = progress;
                break;
        }
        imageview.setBackgroundColor(Color.rgb(red, green, blue));
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {


    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
        Toast.makeText(this, "Code :" + red + ":" + green + ":" + blue, Toast.LENGTH_SHORT).show();

    }

}
