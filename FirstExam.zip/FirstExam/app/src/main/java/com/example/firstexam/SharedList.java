package com.example.firstexam;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class SharedList extends AppCompatActivity {
    Button back, show, add;
    ListView itemList;
    EditText enterItem;
    ArrayList<String> arrayList;
    ArrayAdapter<String> adapter;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_shared_list);
        getSupportActionBar().hide();


        back = findViewById(R.id.back);
        show = findViewById(R.id.show);
        add = findViewById(R.id.add);
        itemList = findViewById(R.id.listItem);
        enterItem = findViewById(R.id.enterItem);

        sharedPreferences = getSharedPreferences("UserInfo", 0);
        arrayList = new ArrayList<String>();
        adapter = new ArrayAdapter<String>(SharedList.this, android.R.layout.simple_dropdown_item_1line, arrayList);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SharedList.this, MainActivity.class);
                startActivity(intent);
            }
        });
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String results = enterItem.getText().toString();
                if (results.length() > 5) {

                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("Data", results);
                    editor.apply();
                    Toast.makeText(SharedList.this, "Added into List", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(SharedList.this, "Please increase the text values", Toast.LENGTH_SHORT).show();
                }


            }
        });
        show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String results = enterItem.getText().toString();
                if (results.isEmpty()) {
                    Toast.makeText(SharedList.this, "Please Enter values", Toast.LENGTH_SHORT).show();


                } else if (itemList.equals(enterItem)) {
                    Toast.makeText(SharedList.this, "Present Value are same", Toast.LENGTH_SHORT).show();

                } else {

                    arrayList.add(results);
                    itemList.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                }

            }
        });


    }


}
