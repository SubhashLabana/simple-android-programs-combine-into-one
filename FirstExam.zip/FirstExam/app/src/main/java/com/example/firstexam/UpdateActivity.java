package com.example.firstexam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class UpdateActivity extends AppCompatActivity {
    Button update1;
    EditText txtid,fname1,lname1;
    TextView back;
    DataBaseHelpher db = new DataBaseHelpher(UpdateActivity.this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        update1=(Button)findViewById(R.id.update1);
        txtid=(EditText)findViewById(R.id.id);
        back=(TextView)findViewById(R.id.back);
        fname1=(EditText)findViewById(R.id.fname1);
        lname1=(EditText)findViewById(R.id.lname1);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UpdateActivity.this,DatabaseActivity.class);
                startActivity(intent);
            }
        });
        update1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UpdateMe();
            }
        });
    }
    private void UpdateMe() {
        String id=txtid.getText().toString();
        String user = fname1.getText().toString();
        String pass = lname1.getText().toString();
        Boolean result = db.UpdateData(id,user, pass);
        if (result == true) {
            Toast.makeText(this, "Data update Succcessfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Data update Unsucccessfully", Toast.LENGTH_SHORT).show();
        }
    }
}
