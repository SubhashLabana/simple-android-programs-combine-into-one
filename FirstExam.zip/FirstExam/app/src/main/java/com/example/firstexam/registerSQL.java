package com.example.firstexam;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class registerSQL extends AppCompatActivity {
    Button register;
    TextView back;
    EditText username , password;
    DataBaseHelpher db = new DataBaseHelpher(registerSQL.this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_s_q_l);
        username=findViewById(R.id.username);
        password=findViewById(R.id.password);
        back=findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(registerSQL.this,SQLDatabase.class);
                startActivity(intent);
            }
        });
        register=findViewById(R.id.register);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AddMe();
            }
        });

    }

    private void AddMe() {
        String user=username.getText().toString();
        String pass=password.getText().toString();

        Boolean result = db.insertData(user,pass);
        if (result == true) {
            Toast.makeText(this, "Data inserted Succcessfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Data inserted Unsucccessfully", Toast.LENGTH_SHORT).show();
        }
    }
}
